package com.example.Actividad_13.model;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CategoriasRepository extends JpaRepository<categorias, Long> {
    List<categorias> findAllByStatusIsTrue();

    ///Querys Personalizadas haciendo uso de JPA

    @Query("SELECT p FROM categorias p")
    List<categorias> findAllProducts();

    @Query("SELECT p FROM categorias p WHERE p.status = true")
    List<categorias> findActiveProducts();

    @Query("SELECT p FROM categorias p WHERE p.id = :id")
    Optional<categorias> findProductById(@Param("id") Long id);

    @Query("SELECT p FROM categorias p WHERE p.name LIKE %:name%")
    List<categorias> findProductsByName(@Param("name") String name);

    @Query(value = "SELECT * FROM categorias", nativeQuery = true)
    List<categorias> findAllProductsNative();

    @Query(value = "SELECT * FROM categorias WHERE status = TRUE", nativeQuery = true)
    List<categorias> findActiveProductsIsActiveNative();

    @Query(value = "SELECT * FROM categorias WHERE id = ?1", nativeQuery = true)
    Optional<categorias> findProductByIdNative(Long id);

}