package com.example.Actividad_13.utils;

public enum TypesResponse {
    SUCCESS,
    ERROR,
    WARNING
}