package com.example.Actividad_13.model;

import jakarta.persistence.*;

@Entity
@Table(name = "categorias") // Cambié "productos" por "categorias"
public class categorias {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", columnDefinition = "VARCHAR(30)")
    private String name;

    @Column(name = "descripcion", columnDefinition = "VARCHAR(30)")
    private String descripcion;

    @Column(name = "status", columnDefinition = "BOOL DEFAULT TRUE")
    private boolean status;

    // Constructor vacío
    public categorias() {
    }

    // Constructor que recibe los atributos
    public categorias(String name, String descripcion, boolean status) {
        this.name = name;
        this.descripcion = descripcion;
        this.status = status;
    }

    // Constructor con todos los campos
    public categorias(Long id, String name, String descripcion, boolean status) {
        this.id = id;
        this.name = name;
        this.descripcion = descripcion;
        this.status = status;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
