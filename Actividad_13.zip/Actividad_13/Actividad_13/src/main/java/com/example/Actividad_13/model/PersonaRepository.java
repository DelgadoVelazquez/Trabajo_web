package com.example.Actividad_13.model;



import com.example.Actividad_13.model.Persona;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.List;

public interface PersonaRepository extends JpaRepository<Persona, Long> {

    Optional<Persona> findByCurp(String curp);
    List<Persona> findByStatus(Boolean status);
}
