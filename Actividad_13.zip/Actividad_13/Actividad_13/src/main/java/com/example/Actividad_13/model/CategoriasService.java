package com.example.Actividad_13.model;

import com.example.Actividad_13.model.CategoriasRepository;
import com.example.Actividad_13.model.categorias;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Transactional
@Service
public class CategoriasService {

    private final CategoriasRepository categoriasRepository;

    @Autowired
    public CategoriasService(CategoriasRepository categoriasRepository) {
        this.categoriasRepository = categoriasRepository;
    }

    @Transactional(readOnly = true)
    public List<categorias> findAll() {
        return categoriasRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional<categorias> findById(Long id) {
        return categoriasRepository.findById(id);
    }

    @Transactional(rollbackFor = {SQLException.class})
    public categorias save(categorias categoria) {
        categoria.setStatus(true);
        return categoriasRepository.save(categoria);
    }

    @Transactional(rollbackFor = {SQLException.class})
    public categorias update(categorias categoria) {
        Optional<categorias> categoriaOptional = categoriasRepository.findById(categoria.getId());
        if (categoriaOptional.isPresent()) {
            categorias categoriaNew = categoriaOptional.get();
            categoriaNew.setName(categoria.getName());
            categoriaNew.setDescripcion(categoria.getDescripcion());
            return categoriasRepository.save(categoriaNew);
        }
        return null;
    }

    public categorias changeStatus(Long id) {
        Optional<categorias> categoriaOptional = categoriasRepository.findById(id);
        if (categoriaOptional.isPresent()) {
            categorias categoriaNew = categoriaOptional.get();
            categoriaNew.setStatus(!categoriaNew.isStatus());
            return categoriasRepository.save(categoriaNew);
        }
        return null;
    }

}
