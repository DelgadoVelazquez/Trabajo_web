package com.example.Actividad_13.control;

import com.example.Actividad_13.model.CategoriasService;
import com.example.Actividad_13.model.categorias;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/product")
public class CategoriasController {  // Cambié de 'CategotiasController' a 'CategoriasController'

    private final CategoriasService categoriasService;

    @Autowired
    public CategoriasController(CategoriasService categoriasService) {  // Nombre del servicio corregido
        this.categoriasService = categoriasService;
    }

    @GetMapping("/all")
    public List<categorias> getAllProducts() {
        return categoriasService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<categorias> getProductById(@PathVariable Long id) {
        return categoriasService.findById(id);
    }

    @PostMapping("/save")
    public categorias saveProduct(@RequestBody categorias product) {
        return categoriasService.save(product);
    }

    @PutMapping("/update")
    public categorias updateProduct(@RequestBody categorias categorias) {
        return categoriasService.update(categorias);
    }

    @DeleteMapping("/{id}")
    public categorias deleteProduct(@PathVariable Long id) {
        return categoriasService.changeStatus(id);
    }
}
