package com.example.Actividad_13.control;

import com.example.Actividad_13.document.Document;
import com.example.Actividad_13.model.DocumentRepository;
import com.example.Actividad_13.utils.Message;
import com.example.Actividad_13.utils.TypesResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Transactional
@Service
public class DocumentService {

    private static final Logger logger = LoggerFactory.getLogger(DocumentService.class);

    private final DocumentRepository documentRepository;

    @Autowired
    public DocumentService(DocumentRepository documentRepository) {
        this.documentRepository = documentRepository;
    }

    @Transactional(readOnly = true)
    public ResponseEntity<Message> findAll() {
        List<Document> documents = documentRepository.findAll();
        logger.info("La búsqueda ha sido realizada correctamente");
        return new ResponseEntity<>(new Message(documents, "Listado de documentos", TypesResponse.SUCCESS), HttpStatus.OK);
    }

    @Transactional(rollbackFor = {SQLException.class})
    public ResponseEntity<Message> save(Document document) {
        String validationError = validateDocumentFields(document);
        if (validationError != null) {
            return new ResponseEntity<>(new Message(validationError, TypesResponse.WARNING), HttpStatus.BAD_REQUEST);
        }

        Document savedDocument = documentRepository.saveAndFlush(document);
        logger.info("El registro ha sido realizado correctamente");
        return new ResponseEntity<>(new Message(savedDocument, "El documento se registró correctamente", TypesResponse.SUCCESS), HttpStatus.CREATED);
    }

    @Transactional(rollbackFor = {SQLException.class})
    public ResponseEntity<Message> update(Document document) {
        Document documentToUpdate = documentRepository.findById(document.getId())
                .orElseThrow(() -> new IllegalArgumentException("El documento no existe"));

        String validationError = validateDocumentFields(document);
        if (validationError != null) {
            return new ResponseEntity<>(new Message(validationError, TypesResponse.WARNING), HttpStatus.BAD_REQUEST);
        }

        documentToUpdate.setName(document.getName());
        documentToUpdate.setDescription(document.getDescription());
        documentRepository.saveAndFlush(documentToUpdate);

        logger.info("La actualización ha sido realizada correctamente");
        return new ResponseEntity<>(new Message(documentToUpdate, "El documento se actualizó correctamente", TypesResponse.SUCCESS), HttpStatus.OK);
    }

    private String validateDocumentFields(Document document) {
        if (document.getName().length() > 30) {
            return "El nombre excede el número de caracteres";
        }
        if (document.getDescription().length() > 70) {
            return "La descripción excede el número de caracteres";
        }
        return null;
    }
}
