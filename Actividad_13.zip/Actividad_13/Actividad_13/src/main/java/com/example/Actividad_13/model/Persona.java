package com.example.Actividad_13.model;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "personas",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = "curp"),
                @UniqueConstraint(columnNames = "telefono")
        })
public class Persona implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre", length = 50, nullable = false)
    private String nombre;

    @Column(name = "apellidos", length = 50, nullable = false)
    private String apellidos;

    @Column(name = "curp", length = 18, nullable = false)
    private String curp;

    @Column(name = "telefono", length = 10, nullable = false)
    private String telefono;

    @Column(name = "status", nullable = false)
    private Boolean status;

    // Constructores
    public Persona() {}

    public Persona(String nombre, String apellidos, String curp, String telefono, Boolean status) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.curp = curp;
        this.telefono = telefono;
        this.status = status;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCurp() {
        return curp;
    }

    public void setCurp(String curp) {
        this.curp = curp;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }
}
