package com.example.Actividad_13.model;



import com.example.Actividad_13.model.Persona;
import com.example.Actividad_13.model.PersonaRepository;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class PersonaService {

    private final PersonaRepository personaRepository;
    private static final Logger logger = LoggerFactory.getLogger(PersonaService.class);

    public PersonaService(PersonaRepository personaRepository) {
        this.personaRepository = personaRepository;
    }

    public List<Persona> getAllPersonas() {
        logger.info("Fetching all personas");
        return personaRepository.findAll();
    }

    public Optional<Persona> getPersonaById(Long id) {
        logger.info("Fetching persona with ID: " + id);
        return personaRepository.findById(id);
    }

    public Persona savePersona(Persona persona) {
        if (personaRepository.findByCurp(persona.getCurp()).isPresent()) {
            throw new IllegalArgumentException("CURP already exists");
        }
        if (personaRepository.findAll().stream().anyMatch(p -> p.getTelefono().equals(persona.getTelefono()))) {
            throw new IllegalArgumentException("Phone number already exists");
        }
        logger.info("Saving new persona: " + persona.getNombre() + " " + persona.getApellidos());
        return personaRepository.save(persona);
    }

    public Persona updatePersona(Long id, Persona personaDetails) {
        Persona persona = personaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Persona not found"));
        persona.setNombre(personaDetails.getNombre());
        persona.setApellidos(personaDetails.getApellidos());
        persona.setCurp(personaDetails.getCurp());
        persona.setTelefono(personaDetails.getTelefono());
        persona.setStatus(personaDetails.getStatus());
        logger.info("Updating persona with ID: " + id);
        return personaRepository.save(persona);
    }

    public void deletePersona(Long id) {
        logger.info("Deleting persona with ID: " + id);
        personaRepository.deleteById(id);
    }

    public void changeStatus(Long id, Boolean status) {
        Persona persona = personaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Persona not found"));
        persona.setStatus(status);
        logger.info("Changing status of persona with ID: " + id + " to " + status);
        personaRepository.save(persona);
    }

    public List<Persona> getAllActivePersonas() {
        logger.info("Fetching all active personas");
        return personaRepository.findByStatus(true);
    }

    public List<Persona> getAllInactivePersonas() {
        logger.info("Fetching all inactive personas");
        return personaRepository.findByStatus(false);
    }

    public Optional<Persona> getPersonaByCurp(String curp) {
        logger.info("Fetching persona with CURP: " + curp);
        return personaRepository.findByCurp(curp);
    }

    // Cron job que se ejecuta cada 2 minutos
    @Scheduled(fixedRate = 120000)
    public void logLastRegisteredPersona() {
        personaRepository.findAll().stream().reduce((first, second) -> second).ifPresent(persona ->
                logger.info("Última persona registrada: " + persona.getNombre() + " " + persona.getApellidos()));
    }
}
